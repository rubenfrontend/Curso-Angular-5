import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { Pais } from './pais';

@Injectable()
export class PaisesService {
    PAISES = [
        new Pais(3, 'Argentina', 'arg.png', 43131966, 'https://es.wikipedia.org/wiki/Argentina'),
        new Pais(2, 'Bélgica', 'bel.png', 11250659, 'https://es.wikipedia.org/wiki/B%C3%A9lgica'),
        new Pais(1, 'España', 'esp.png', 46524949, 'https://es.wikipedia.org/wiki/Espa%C3%B1a'),
        new Pais(4, 'Suazilandia', 'sua.png', 1018449, 'https://es.wikipedia.org/wiki/ Suazilandia'),
    ];

    constructor(private http: HttpClient) {
    }

    getAll() { // devuelve todos los países tendrá que devolver el array completo de todos los países.
        return this.PAISES;
    }

    getByPoblacion(poblacion) { // Filter: especifica un método que nos permite decir cómo vamos a filtrar dentro del array
        return this.PAISES.filter(elemento =>
                elemento.poblacion > poblacion
        );
    }

    getOrdenados() { // Sort: para especificar cómo ordenamos los países.
        return this.PAISES.sort(
            (n1, n2) =>
            n1.id - n2.id
        );
    }

    añadirPais(pais: Pais) {
        this.PAISES.push(pais);
    }
}
