import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Pais } from '../pais';

@Component({
  selector: 'app-paises-form',
  templateUrl: './paises-form.component.html',
  styleUrls: ['./paises-form.component.css']
})
export class PaisesFormComponent implements OnInit {

  @Output() modelEmitter = new EventEmitter();
  model = new Pais(0, 'Default', 'default', 0, 'default');
  submitted = false;

  constructor() { }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
    this.modelEmitter.emit(this.model);
    this.model = new Pais(0, 'Default', 'default', 0, 'default');
  }
}
