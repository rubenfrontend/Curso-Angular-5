import { Component } from '@angular/core';
import { Empleado } from './empleado';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';

@Component({
    selector: 'app-listaempleados',
    templateUrl: './listaempleados.component.html',
    styleUrls: ['./listaempleados.component.css'],
})

export class ListaEmpleadosComponent {
    listadoEmpleados: Empleado[] = [];
    mostrar: boolean = true;
    nombre: string;
    apellidos: string;
    departamento: string;

    opcion: number;  setDoor(num: number) {
        this.opcion = num;
    }

    constructor(private fb: FormBuilder) {
        this.listadoEmpleados = [
            new Empleado('Mario', 'Giron', 'Formacion'),
            new Empleado('Antonio', 'Lopez', 'Formacion'),
            new Empleado('Raul', 'Garcia', 'Contabilidad'),
            new Empleado('María', 'García', 'Formacion')
        ];

        // console.log('EMPLEADOS: ', this.listadoEmpleados);
    }

    Mostrar() {
        this.mostrar = !this.mostrar;
    }

    agregarNuevoEmpleado(nombre: string, apellidos: string, departamento: string) {
        const empleado = new Empleado(this.nombre, this.apellidos, this.departamento);
        this.listadoEmpleados.push(empleado);
        // Reset Inputs
        this.nombre = '';
        this.apellidos = '';
        this.departamento = '';
    }
}
