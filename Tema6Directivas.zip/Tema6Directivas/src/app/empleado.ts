import { Component } from '@angular/core';
import { ListaEmpleadosComponent } from './listaempleados.component';

export class Empleado {
    nombre: string;  apellidos: string;  departamento: string;
    constructor(nombre: string, apellidos: string, departamento: string) {
        this.nombre = nombre;    this.apellidos = apellidos;    this.departamento = departamento;
    }
}
