enum Tipo {
  Completa,
  Incompleta,
  Eliminada
}

class Todo {
  mensaje: string;
  tipo: Tipo;

  constructor(mensaje: string, tipo: Tipo) {
    this.mensaje;
    this.tipo;
  }

  isCompleta = () => {
    if (this.tipo === Tipo.Completa) return true;
    else return false;
  };

  marcarCompleta = () => {
      //modifica el tipo del objeto Todo y lo cambia a completa.*/
      this.tipo = Tipo.Completa;
  }

}

class ListadoTareas {
  listado: Todo[] = [];

  constructor() {
    this.listado;
  }

  mostrarListado(indice?: number){
    /* recibe como parámetro un argumento de tipo número opcional. Si en la llamada recibimos el parámetro, sólo tendremos que mostrar
    el número de tareas que nos indique. Si no viene definido, devolveremos todas las tareas del listado. */
    if(indice){
      for (let i = 0; i <= indice-1; i++) {
          var texto = `[ Mensaje:  ${ this.listado[i].mensaje }, ${ Tipo[this.listado[i].tipo] } ].`;
          console.log(texto);
      }
    }else{
      for (let tarea of this.listado) {
            console.log(`[ Mensaje:  ${ tarea.mensaje }, ${ Tipo[tarea.tipo] } ].`);
      }
    }
  
  }

  agregarNuevaTarea = ( tar ) => {
    let tarea = tar;
    tarea.push(this.listado);
  };
}


let todo1 = new Todo("Primera tarea", Tipo.Completa);
let todo2 = new Todo("Segunda tarea", Tipo.Incompleta);
let lista = new ListadoTareas();
lista.agregarNuevaTarea(todo1);
lista.agregarNuevaTarea(todo2);
// Solo muestra el primer elemento
lista.mostrarListado(1);
// Muestra todo el listado
lista.mostrarListado();
