class Persona {
    constructor(nombre, apellido, dni) {
        // Inicializa las variables
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
    }
}

class Trabajador extends Persona {
    constructor(nombre, apellido, dni, nombreEmpresa, direccionEmpresa) {
        // Inicializa las variables
        super();
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.nombreEmpresa = nombreEmpresa;
        this.direccionEmpresa = direccionEmpresa;
    }
}

// Crea un trabajador y muestra alguno de sus atributos

let trabajador = new Trabajador(
    "Ricardo",
    "Tortajada",
    "46532249M",
    "Circutor",
    "Av.Paralel"
);
console.log(trabajador);

/*-----------------------------------------------------------------------------------------------------*/

let numeros = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

let sumaArray = (numeros) => {
    let suma = 0;

    numeros.forEach(element => {
        suma += element;
    });
    // Devuelve la suma de todos los elementos.
    console.log('La suma del array de 10 posiciones és: ', suma);
    return suma;
}

sumaArray(numeros);