export class Tarea {
    mensaje: string;
    completa: boolean;

    constructor(mensaje: string, completa: boolean) {
        this.mensaje = mensaje;
        this.completa = completa;
    }

    cambiarCompleta() {
        this.completa = !this.completa;
    }
}
