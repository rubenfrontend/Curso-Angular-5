import { Component } from '@angular/core';
import { ListadoTareas } from '../lista';
import { TodoComponent } from '../todo/todo.component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css']
})
export class TodoListComponent {
  listado: ListadoTareas;
  textoNuevo: string;
  constructor() {
    this.listado = new ListadoTareas();
  }
  crearNuevaTarea() {
    this.listado.agregarNuevaTarea(this.textoNuevo);
    this.textoNuevo = '';
  }
}
