import { Tarea } from './tarea';
export class ListadoTareas {
  listado: Tarea[] = [];
  constructor() {
    const tareaDefecto = new Tarea('Tarea de ejemplo', false);
    this.listado.push(tareaDefecto);
  }
  agregarNuevaTarea(mensaje: string) {
    const tarea = new Tarea(mensaje, false);
    this.listado.push(tarea);
  }
}
