import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { PaisesService } from '../paises.service';

@Component({
  selector: 'app-paises',
  templateUrl: './paises.component.html',
  styleUrls: ['./paises.component.css'],
  providers: [PaisesService]
})
export class PaisesComponent implements OnInit {
  country: any;
  listaPaises: any;
  ordena: any;

  constructor(private http: HttpClient, public paises: PaisesService) {}

  ngOnInit() {
    this.country = this.paises.getAll();
  }

  onChange($event) {
    this.listaPaises = this.paises.getByPoblacion($event.target.value);
  }

  order() {
    this.paises.getOrdenados();
  }

}
