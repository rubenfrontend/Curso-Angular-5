import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { PaisesComponent } from './paises/paises.component';
import { PaispornombrepipePipe } from './paispornombrepipe.pipe';


@NgModule({
  declarations: [
    AppComponent,
    PaisesComponent,
    PaispornombrepipePipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
