import { Component, OnInit, PipeTransform } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { PaisesService } from '../paises.service';
import { PaispornombrepipePipe } from '../paispornombrepipe.pipe';

@Component({
  selector: 'app-paises',
  templateUrl: './paises.component.html',
  styleUrls: ['./paises.component.css'],
  providers: [PaisesService, PaispornombrepipePipe],
})
export class PaisesComponent implements OnInit {
  country: any;
  listaPaises: any;
  ordena: any;

  constructor(private http: HttpClient, public paises: PaisesService, public paisFilter: PaispornombrepipePipe) {}

  ngOnInit() {
    this.country = this.paises.getAll();
  }

  onChange($event) {
    this.country = this.paises.getByPoblacion($event.target.value);
  }

  order() {
    this.paises.getOrdenados();
  }

}
