import { Pipe, PipeTransform } from '@angular/core';
import { Pais } from './pais';

@Pipe({
    name: 'paisFilter'
})

export class PaispornombrepipePipe implements PipeTransform {

  transform (value: any, arg: any): any {
    console.log(arg);
    const filtro = arg.toLocaleLowerCase();
    return filtro ? value.filter(pais => pais.nombre.toLocaleLowerCase().indexOf(filtro) !== -1) : value;
}

}
