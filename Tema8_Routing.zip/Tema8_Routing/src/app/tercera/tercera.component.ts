import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  moduleId: module.id,
  selector: 'app-tercera',
  templateUrl: 'tercera.component.html',
  styleUrls: ['tercera.component.css']
})

export class TerceraComponent implements OnInit {
  param: string;
  constructor(private route: ActivatedRoute) {}
  ngOnInit(): void {
    this.route.params.forEach((params: Params) => {
      if (params['param'] !== undefined) {
        this.param = params['param'];
        console.log(this.param);
      } else {
        this.param = 'DEFAULT';
      }
    });
  }
}
