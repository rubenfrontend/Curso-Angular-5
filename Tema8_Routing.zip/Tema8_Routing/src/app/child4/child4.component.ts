import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  moduleId: module.id,
  selector: 'app-child4',
  templateUrl: 'child4.component.html',
  styleUrls: ['child4.component.css']
})
export class Child4Component implements OnInit {
  param: String;
  router: any;
  sub: any;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.sub = this.route.parent
      .params.subscribe(params => {
        this.param = params.param;
      });
  }
}
