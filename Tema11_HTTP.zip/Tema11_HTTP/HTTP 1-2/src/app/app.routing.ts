import { Routes, RouterModule } from '@angular/router';

import { JugadoresComponent } from './jugadores/jugadores.component';

const appRoutes: Routes = [
  { path: '', redirectTo: 'jugadores', pathMatch: 'full' },
  { path: 'jugadores', component: JugadoresComponent },
];

export const APP_ROUTES = RouterModule.forRoot(appRoutes);
