import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

// Imports for loading & configuring the in-memory web api
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './services/in-memory-data.service';

import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { APP_ROUTES } from './app.routing';
import { JugadoresComponent } from './jugadores/jugadores.component';

import * as Rx from 'rxjs';

@NgModule({
  declarations: [
    AppComponent,
    JugadoresComponent
  ],
  imports: [
    BrowserModule,
    APP_ROUTES,
    BrowserModule,
    HttpClientModule,
    InMemoryWebApiModule.forRoot(InMemoryDataService)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
