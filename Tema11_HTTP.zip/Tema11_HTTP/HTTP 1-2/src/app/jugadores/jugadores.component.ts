import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Router } from '@angular/router';

import { Jugador } from '../class/jugador';
import { JugadoresService } from '../class/jugadores-service';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({

  selector: 'app-jugadores',
  templateUrl: './jugadores.component.html',
  styleUrls: ['./jugadores.component.css'],
  providers: [JugadoresService]
})
export class JugadoresComponent implements OnInit {
  // CON PROMESAS
  // jugadores: Jugador[];

  // CON OBSERVABLES
  jugadores: Observable<Jugador[]>;

  constructor(private jugadoresService: JugadoresService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getJugadores();
  }

  // CON PROMESAS
  // getJugadores(): void {
  //   this.jugadoresService.getJugadores()
  //   .then(jugadores => this.jugadores = jugadores);
  // }

  // CON OBSERVABLES
  getJugadores(): void {
    this.jugadores = this.jugadoresService.getJugadores();
    }
}
