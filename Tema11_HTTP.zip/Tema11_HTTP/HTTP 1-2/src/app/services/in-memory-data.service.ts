import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService {
  createDb() {
    // Completar con la lista de objetos que queremos obtener y devolverla.
    const jugadores = [
      {id: 1, name: 'Iago Aspas'},
      {id: 2, name: 'Hugo Mallo'},
      {id: 3, name: 'Maxi Gómez'},
      {id: 4, name: 'Pione Sisto'},
      {id: 5, name: 'Emre Mor'},
      {id: 6, name: 'Daniel Wass'},
      {id: 7, name: 'Stanislav Lobotka'}
      ];
      return {
        jugadores
      };
  }
  constructor() { }
}
