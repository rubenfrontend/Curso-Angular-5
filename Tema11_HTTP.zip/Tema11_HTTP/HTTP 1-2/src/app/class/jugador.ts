export class Jugador {
    id: number;
    name: string;
}
