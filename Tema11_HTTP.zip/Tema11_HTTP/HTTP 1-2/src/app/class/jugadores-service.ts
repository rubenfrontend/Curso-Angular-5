import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Jugador } from './jugador';

// CON OBSERVABLES
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()

export class JugadoresService {
    private headers = new Headers({'Content-Type': 'application/json'});
    private jugadoresUrl = 'app/jugadores'; // URL to web api

    constructor(private http: HttpClient) { }

    // CON PROMESAS
    // getJugadores(): Promise<Jugador[]> {
    //     return this.http.get(this.jugadoresUrl)
    //     .toPromise()
    //     .then(response => response as Jugador[])
    //     .catch(this.handleError);
    // }

    // private handleError(error: any): Promise<any> {
    //     console.error('An error occurred', error); // for demo purposes only
    //     return Promise.reject(error.message || error);
    // }

    // CON OBSERVABLES
    getJugadores(): Observable<Jugador[]> {
        return this.http.get(this.jugadoresUrl).pipe(map(response => response as Jugador[]));
    }
}
