import { Routes, RouterModule } from '@angular/router';

import { GetpersonasComponent } from './getpersonas/getpersonas.component';

const appRoutes: Routes = [
  { path: '', redirectTo: 'personas', pathMatch: 'full' },
  { path: 'personas', component: GetpersonasComponent },
];

export const APP_ROUTES = RouterModule.forRoot(appRoutes);
