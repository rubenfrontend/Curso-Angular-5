import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';

import { RouterModule, Routes } from '@angular/router';
import { APP_ROUTES } from './app.routing';
import { ActivatedRoute, Params } from '@angular/router';

import { GetpersonasComponent } from './getpersonas/getpersonas.component';

@NgModule({
  declarations: [
    AppComponent,
    GetpersonasComponent
  ],
  imports: [
    BrowserModule,
    BrowserModule,
    HttpClientModule,
    APP_ROUTES
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
