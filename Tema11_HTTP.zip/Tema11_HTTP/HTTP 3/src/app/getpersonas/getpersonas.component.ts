import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-getpersonas',
  templateUrl: './getpersonas.component.html',
  styleUrls: ['./getpersonas.component.css']
})

export class GetpersonasComponent implements OnInit {
  arrayPersonas = [];
  image = [];
  name = [];
  lastname = [];
  email = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
  }

  addPersona() {
    this.http
      .get('https://randomuser.me/api/?results=1')
      .pipe(map(res => res))
      .subscribe(
        data => {
            // peticion a la API
            const lineas: string =
            '<div style="display:flex; justify-content:center; margin-top:2%;">' +
            '<img style="float:left;" src="' + data.results[0].picture.thumbnail + '" alt="" width="150" height="150">' +
            '<div style="float:left; margin-left:2%;">' +
            '<p><strong>Nombre: </strong>' + data.results[0].name.first + '</p>' + '<p><strong>Apellidos: </strong>' +
            data.results[0].name.last + '</p>' + '<p><strong>Email: </strong>' + data.results[0].email +
            '</p>' + '</div>' + '</div>';
            const elemento = document.createElement('div');
            elemento.innerHTML = lineas;
            const contenedor = document.getElementById('contenedor');
            contenedor.appendChild(elemento);
        },
        err => {
          console.log('Error');
        }
      );

  }
}
